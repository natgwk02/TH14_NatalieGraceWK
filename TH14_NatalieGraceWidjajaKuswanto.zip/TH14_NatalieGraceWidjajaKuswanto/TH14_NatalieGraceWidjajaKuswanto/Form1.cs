﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace TH14_NatalieGraceWidjajaKuswanto
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        string query;
        DataTable dtTeamHome = new DataTable();
        DataTable dtTeamAway = new DataTable();
        DataTable dtPlayer = new DataTable();
        DataTable dtTeam;
        DataTable dtTanggal;
        DataTable dtDGV;
        DataTable dtlengkap;
       
        int goalhome = 0;
        int goalaway = 0;
        string tanggalterakhir = "2/14/2016 12:00:00 AM";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection("server=localhost;uid=root;pwd=Natalie02_;database=premier_league;");
            query = "select * from team";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtTeamHome);
            cb_teamhome.DataSource = dtTeamHome;
            cb_teamhome.ValueMember = "team_id";
            cb_teamhome.DisplayMember = "team_name";

            cb_teamhome.Text = "";
           
            query = @"select * from team;";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtTeamAway);
            cb_teamaway.DataSource = dtTeamAway;
            cb_teamaway.ValueMember = "team_id";
            cb_teamaway.DisplayMember = "team_name";

            cb_teamaway.Text = "";

            cb_type.Items.Add("GO");
            cb_type.Items.Add("GP");
            cb_type.Items.Add("GW");
            cb_type.Items.Add("CR");
            cb_type.Items.Add("CP");
            cb_type.Items.Add("PY");

            dtDGV = new DataTable();
            dtDGV.Columns.Add("Team");
            dtDGV.Columns.Add("Player");
            dtDGV.Columns.Add("Type");
            dgv_1.DataSource = dtDGV;

            dtlengkap = new DataTable();
            dtlengkap.Columns.Add("Minute");
            dtlengkap.Columns.Add("team_id");
            dtlengkap.Columns.Add("player_id");
            dtlengkap.Columns.Add("type");
        }

        private void cb_teamhome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamhome.Text == cb_teamaway.Text)
            {
                MessageBox.Show("Nama team tidak boleh sama");
            }
            else
            {
                dtTeam = new DataTable();
                query = $"select team_id, team_name from team where team_id = '{cb_teamaway.SelectedValue}' or team_id = '{cb_teamhome.SelectedValue}'";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtTeam);
                cb_team.DataSource = dtTeam;
                cb_team.ValueMember = "team_id";
                cb_team.DisplayMember = "team_name";

                cb_team.Text = "";
                cb_player.Text = "";
            }
        }

        private void cb_teamaway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamhome.Text == cb_teamaway.Text)
            {
                MessageBox.Show("Nama team tidak boleh sama");
            }
            else
            {
                dtTeam = new DataTable();
                query = $"select team_id, team_name from team where team_id = '{cb_teamaway.SelectedValue}' or team_id = '{cb_teamhome.SelectedValue}'";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtTeam);
                cb_team.DataSource = dtTeam;
                cb_team.ValueMember = "team_id";
                cb_team.DisplayMember = "team_name";

                cb_team.Text = "";
                cb_player.Text = "";
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            if (dtp_1.Value < Convert.ToDateTime(tanggalterakhir))
            {
                MessageBox.Show("Tanggal harus lebih besar daripada pertandingan terakhir");
                btn_insert.Enabled = false;
            }
            else
            {
                btn_insert.Enabled = true;
                query = $"select count(match_id) from `match` where match_id like '{dtp_1.Value.Year}%' order by 1 desc; ";
                dtTanggal = new DataTable();
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtTanggal);

                int jumlah = Convert.ToInt32(dtTanggal.Rows[0][0]) + 1;
                if (jumlah > 0 && jumlah < 10)
                {
                    tb_matchid.Text = $"{dtp_1.Value.Year}00{jumlah}";
                }
                else if (jumlah > 9 && jumlah < 99)
                {
                    tb_matchid.Text = $"{dtp_1.Value.Year}0{jumlah}";
                }
                else
                {
                    tb_matchid.Text = $"{dtp_1.Value.Year}{jumlah}";
                }
            }
        }


        private void btn_add_Click(object sender, EventArgs e)
        {
            string tipe = cb_type.Text;

            if (tipe == "GO" || tipe == "GP")
            {
                if (cb_team.Text == cb_teamhome.Text)
                {
                    goalhome++;
                }
                else 
                {
                    goalaway++;
                }
            }
            else if (tipe == "GW")
            {
                if (cb_team.Text == cb_teamhome.Text)
                {
                    goalaway++;
                }
                else
                {
                    goalhome++;
                }
            }
            
            dtlengkap.Rows.Add(tb_minute.Text, cb_team.SelectedValue.ToString(), cb_player.SelectedValue.ToString(), cb_type.Text);
            dtDGV.Rows.Add(cb_team.Text, cb_player.Text, cb_type.Text);
            dgv_1.DataSource = dtDGV;
            tanggalterakhir = dtp_1.Value.Date.ToString();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = dgv_1.CurrentRow;
            int remove = 0;
            if (dgv_1.Rows.Count != 0)
            {
                for (int i=0; i < dtDGV.Rows.Count; i++)
                {
                    if (dtDGV.Rows[i][0].ToString().Contains(row.Cells[0].Value.ToString()))
                    {
                        remove = i;
                    }
                }

                if (row.Cells[2].Value.ToString() == "GO" || row.Cells[2].Value.ToString() == "GP")
                {
                    if (cb_team.Text == cb_teamhome.Text)
                    {
                        goalhome--;
                    }
                    else
                    {
                        goalaway--;
                    }
                }
                else if (row.Cells[2].Value.ToString() == "GW")
                {
                    if (cb_team.Text == cb_teamhome.Text)
                    {
                        goalaway--;
                    }
                    else
                    {
                        goalhome--;
                    }
                }
                dtDGV.Rows.RemoveAt(remove);
                dtlengkap.Rows.RemoveAt(remove);
            }

            dgv_1.DataSource = dtDGV;
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            string day = dtp_1.Value.Day.ToString();
            string month = dtp_1.Value.Month.ToString();
            string year = dtp_1.Value.Year.ToString();
            string date = $"{year}-{month}-{day}";

            for (int i = 0; i < dgv_1.Rows.Count; i++)
            {
                query = $"insert into dmatch values ('{tb_matchid.Text}', '{dtlengkap.Rows[i][0].ToString()}', '{dtlengkap.Rows[i][1].ToString()}', '{dtlengkap.Rows[i][2].ToString()}', '{dtlengkap.Rows[i][3].ToString()}','0');";             
                sqlConnect.Open();
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlCommand.ExecuteNonQuery();
                sqlConnect.Close();
            }

            query = $"insert into `match` values('{tb_matchid.Text}', '{date}','{cb_teamhome.SelectedValue}','{cb_teamaway.SelectedValue}','{goalhome.ToString()}','{goalaway.ToString()}','M002','0')";

            sqlConnect.Open();
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlCommand.ExecuteNonQuery();
            sqlConnect.Close();
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtPlayer = new DataTable();
            query = $@"select * from player 
where team_id = '{cb_team.SelectedValue}';";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtPlayer);
            dgv_1.DataSource = dtDGV;
            cb_player.DataSource = dtPlayer;
            cb_player.ValueMember = "player_id";
            cb_player.DisplayMember = "player_name";
            cb_player.Text = "";
        }
    }
}
