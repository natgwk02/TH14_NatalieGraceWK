﻿namespace TH14_NatalieGraceWidjajaKuswanto
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_matchid = new System.Windows.Forms.Label();
            this.lb_teamhome = new System.Windows.Forms.Label();
            this.lb_matchdate = new System.Windows.Forms.Label();
            this.lb_teamaway = new System.Windows.Forms.Label();
            this.lb_team = new System.Windows.Forms.Label();
            this.lb_player = new System.Windows.Forms.Label();
            this.lb_type = new System.Windows.Forms.Label();
            this.lb_minute = new System.Windows.Forms.Label();
            this.tb_matchid = new System.Windows.Forms.TextBox();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.cb_teamhome = new System.Windows.Forms.ComboBox();
            this.cb_teamaway = new System.Windows.Forms.ComboBox();
            this.dtp_1 = new System.Windows.Forms.DateTimePicker();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.dgv_1 = new System.Windows.Forms.DataGridView();
            this.btn_insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_matchid
            // 
            this.lb_matchid.AutoSize = true;
            this.lb_matchid.Location = new System.Drawing.Point(37, 36);
            this.lb_matchid.Name = "lb_matchid";
            this.lb_matchid.Size = new System.Drawing.Size(51, 13);
            this.lb_matchid.TabIndex = 0;
            this.lb_matchid.Text = "Match ID";
            // 
            // lb_teamhome
            // 
            this.lb_teamhome.AutoSize = true;
            this.lb_teamhome.Location = new System.Drawing.Point(27, 71);
            this.lb_teamhome.Name = "lb_teamhome";
            this.lb_teamhome.Size = new System.Drawing.Size(65, 13);
            this.lb_teamhome.TabIndex = 1;
            this.lb_teamhome.Text = "Team Home";
            // 
            // lb_matchdate
            // 
            this.lb_matchdate.AutoSize = true;
            this.lb_matchdate.Location = new System.Drawing.Point(236, 36);
            this.lb_matchdate.Name = "lb_matchdate";
            this.lb_matchdate.Size = new System.Drawing.Size(63, 13);
            this.lb_matchdate.TabIndex = 2;
            this.lb_matchdate.Text = "Match Date";
            // 
            // lb_teamaway
            // 
            this.lb_teamaway.AutoSize = true;
            this.lb_teamaway.Location = new System.Drawing.Point(236, 74);
            this.lb_teamaway.Name = "lb_teamaway";
            this.lb_teamaway.Size = new System.Drawing.Size(63, 13);
            this.lb_teamaway.TabIndex = 3;
            this.lb_teamaway.Text = "Team Away";
            // 
            // lb_team
            // 
            this.lb_team.AutoSize = true;
            this.lb_team.Location = new System.Drawing.Point(406, 179);
            this.lb_team.Name = "lb_team";
            this.lb_team.Size = new System.Drawing.Size(34, 13);
            this.lb_team.TabIndex = 7;
            this.lb_team.Text = "Team";
            // 
            // lb_player
            // 
            this.lb_player.AutoSize = true;
            this.lb_player.Location = new System.Drawing.Point(406, 211);
            this.lb_player.Name = "lb_player";
            this.lb_player.Size = new System.Drawing.Size(36, 13);
            this.lb_player.TabIndex = 6;
            this.lb_player.Text = "Player";
            // 
            // lb_type
            // 
            this.lb_type.AutoSize = true;
            this.lb_type.Location = new System.Drawing.Point(406, 243);
            this.lb_type.Name = "lb_type";
            this.lb_type.Size = new System.Drawing.Size(31, 13);
            this.lb_type.TabIndex = 5;
            this.lb_type.Text = "Type";
            // 
            // lb_minute
            // 
            this.lb_minute.AutoSize = true;
            this.lb_minute.Location = new System.Drawing.Point(406, 146);
            this.lb_minute.Name = "lb_minute";
            this.lb_minute.Size = new System.Drawing.Size(39, 13);
            this.lb_minute.TabIndex = 4;
            this.lb_minute.Text = "Minute";
            // 
            // tb_matchid
            // 
            this.tb_matchid.Location = new System.Drawing.Point(94, 33);
            this.tb_matchid.Name = "tb_matchid";
            this.tb_matchid.Size = new System.Drawing.Size(100, 20);
            this.tb_matchid.TabIndex = 8;
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(462, 143);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(100, 20);
            this.tb_minute.TabIndex = 9;
            // 
            // cb_teamhome
            // 
            this.cb_teamhome.FormattingEnabled = true;
            this.cb_teamhome.Location = new System.Drawing.Point(94, 68);
            this.cb_teamhome.Name = "cb_teamhome";
            this.cb_teamhome.Size = new System.Drawing.Size(100, 21);
            this.cb_teamhome.TabIndex = 10;
            this.cb_teamhome.SelectedIndexChanged += new System.EventHandler(this.cb_teamhome_SelectedIndexChanged);
            // 
            // cb_teamaway
            // 
            this.cb_teamaway.FormattingEnabled = true;
            this.cb_teamaway.Location = new System.Drawing.Point(305, 71);
            this.cb_teamaway.Name = "cb_teamaway";
            this.cb_teamaway.Size = new System.Drawing.Size(100, 21);
            this.cb_teamaway.TabIndex = 11;
            this.cb_teamaway.SelectedIndexChanged += new System.EventHandler(this.cb_teamaway_SelectedIndexChanged);
            // 
            // dtp_1
            // 
            this.dtp_1.Location = new System.Drawing.Point(305, 36);
            this.dtp_1.Name = "dtp_1";
            this.dtp_1.Size = new System.Drawing.Size(200, 20);
            this.dtp_1.TabIndex = 12;
            this.dtp_1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(462, 176);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(100, 21);
            this.cb_team.TabIndex = 13;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(462, 211);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(100, 21);
            this.cb_player.TabIndex = 14;
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Location = new System.Drawing.Point(462, 243);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(100, 21);
            this.cb_type.TabIndex = 15;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(409, 270);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 16;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(507, 270);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 17;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // dgv_1
            // 
            this.dgv_1.AllowUserToAddRows = false;
            this.dgv_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_1.Location = new System.Drawing.Point(30, 131);
            this.dgv_1.Name = "dgv_1";
            this.dgv_1.Size = new System.Drawing.Size(323, 150);
            this.dgv_1.TabIndex = 18;
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(314, 318);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(127, 23);
            this.btn_insert.TabIndex = 19;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.dgv_1);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.dtp_1);
            this.Controls.Add(this.cb_teamaway);
            this.Controls.Add(this.cb_teamhome);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.tb_matchid);
            this.Controls.Add(this.lb_team);
            this.Controls.Add(this.lb_player);
            this.Controls.Add(this.lb_type);
            this.Controls.Add(this.lb_minute);
            this.Controls.Add(this.lb_teamaway);
            this.Controls.Add(this.lb_matchdate);
            this.Controls.Add(this.lb_teamhome);
            this.Controls.Add(this.lb_matchid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_matchid;
        private System.Windows.Forms.Label lb_teamhome;
        private System.Windows.Forms.Label lb_matchdate;
        private System.Windows.Forms.Label lb_teamaway;
        private System.Windows.Forms.Label lb_team;
        private System.Windows.Forms.Label lb_player;
        private System.Windows.Forms.Label lb_type;
        private System.Windows.Forms.Label lb_minute;
        private System.Windows.Forms.TextBox tb_matchid;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.ComboBox cb_teamhome;
        private System.Windows.Forms.ComboBox cb_teamaway;
        private System.Windows.Forms.DateTimePicker dtp_1;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.DataGridView dgv_1;
        private System.Windows.Forms.Button btn_insert;
    }
}

